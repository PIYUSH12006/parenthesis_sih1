const STORAGE_KEY='kisansetuProcurement';
const stages=['Request Submitted','Token Generated','Scheduled','Arrived at Center','Quality Check','Weighing Completed','Procurement Approved','Completed'];
const defaultData={id:'KS-2026-00421',farmer:'Ramesh Kumar',crop:'Wheat',quantity:50,actualQuantity:50,center:'Ghaziabad Wheat Center',token:125,slot:'10:00 AM - 11:00 AM',stage:4,quality:'Pending',serving:118};
let data=load();
function load(){try{return {...defaultData,...JSON.parse(localStorage.getItem(STORAGE_KEY)||'{}')}}catch(e){return {...defaultData}}}
function save(){localStorage.setItem(STORAGE_KEY,JSON.stringify(data))}
function render(){
 document.getElementById('trackingId').value=data.id; document.getElementById('farmerName').textContent=data.farmer; document.getElementById('crop').textContent=data.crop; document.getElementById('quantity').textContent=data.actualQuantity+' Quintals'; document.getElementById('center').textContent=data.center; document.getElementById('token').textContent='#'+data.token; document.getElementById('queueToken').textContent='#'+data.token; document.getElementById('slot').textContent=data.slot; document.getElementById('serving').textContent='#'+data.serving; const ahead=Math.max(0,data.token-data.serving); document.getElementById('ahead').textContent=ahead; document.getElementById('wait').textContent=(ahead*3)+' min';
 const badge=document.getElementById('statusBadge'); badge.textContent=stages[data.stage]; badge.className='badge '+(data.stage>=stages.length-1?'':'warning');
 const pct=Math.round((data.stage/(stages.length-1))*100); document.getElementById('progressText').textContent=pct+'%'; document.getElementById('progressBar').style.width=pct+'%';
 document.getElementById('timeline').innerHTML=stages.map((s,i)=>`<div class="step ${i<data.stage?'done':''} ${i===data.stage?'current':''}"><div class="circle">${i<data.stage?'✓':i+1}</div><h4>${s}</h4><p>${i<data.stage?'Completed':i===data.stage?'Current':'Pending'}</p></div>`).join('');
}
function trackProcurement(){const id=document.getElementById('trackingId').value.trim().toUpperCase();if(!id)return showToast('Enter a Procurement ID');if(id!==data.id){showToast('No procurement record found for '+id);return}showToast('Procurement record loaded');render()}
function showToast(msg){const t=document.getElementById('toast');t.textContent=msg;t.style.display='block';clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.style.display='none',3000)}
render();
